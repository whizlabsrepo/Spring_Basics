package com.whizlabs.spring.basics.bean.finetuning;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class FineTuningConfig {
}
