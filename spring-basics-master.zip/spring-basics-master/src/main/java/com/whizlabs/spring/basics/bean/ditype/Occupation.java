package com.whizlabs.spring.basics.bean.ditype;

public class Occupation {
    private String jobTitle;

    public Occupation(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobTitle() {
        return jobTitle;
    }
}
