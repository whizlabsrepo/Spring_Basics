package com.whizlabs.spring.basics.aop.pointcut.service;

public interface LogService {
    void log(String message);
}
