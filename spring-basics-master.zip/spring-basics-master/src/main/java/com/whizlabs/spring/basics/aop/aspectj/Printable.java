package com.whizlabs.spring.basics.aop.aspectj;

public interface Printable {
    void printFullName();
}
