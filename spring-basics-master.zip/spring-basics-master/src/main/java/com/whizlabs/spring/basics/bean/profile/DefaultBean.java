package com.whizlabs.spring.basics.bean.profile;

public class DefaultBean {
}
