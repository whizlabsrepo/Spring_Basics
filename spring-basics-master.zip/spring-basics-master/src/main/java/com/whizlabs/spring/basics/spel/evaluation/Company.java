package com.whizlabs.spring.basics.spel.evaluation;

public class Company {
    private String name;

    public Company(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
