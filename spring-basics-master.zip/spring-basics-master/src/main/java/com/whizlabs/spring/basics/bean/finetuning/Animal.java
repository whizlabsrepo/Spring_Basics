package com.whizlabs.spring.basics.bean.finetuning;

public interface Animal {
    String move();
}
