package com.whizlabs.spring.basics.resource.loading;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class LoadingConfig {
}
