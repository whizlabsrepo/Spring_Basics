package com.whizlabs.spring.basics.bean.profile;

import org.springframework.stereotype.Component;

@Component
@DevAndProdProfile
public class DevAndProdBean {
}
