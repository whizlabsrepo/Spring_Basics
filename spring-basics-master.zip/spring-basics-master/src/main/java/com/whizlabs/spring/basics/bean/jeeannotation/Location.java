package com.whizlabs.spring.basics.bean.jeeannotation;

public class Location {
    private String address;

    public Location(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }
}
