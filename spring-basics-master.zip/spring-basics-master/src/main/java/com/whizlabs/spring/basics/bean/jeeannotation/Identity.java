package com.whizlabs.spring.basics.bean.jeeannotation;

public class Identity {
    private String fullName;

    public Identity(String fullName) {
        this.fullName = fullName;
    }

    public String getFullName() {
        return fullName;
    }
}
