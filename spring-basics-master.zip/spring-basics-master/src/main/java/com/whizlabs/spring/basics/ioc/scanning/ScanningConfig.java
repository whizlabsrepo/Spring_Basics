package com.whizlabs.spring.basics.ioc.scanning;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.whizlabs.spring.basics.ioc.scanning")
public class ScanningConfig {
}
